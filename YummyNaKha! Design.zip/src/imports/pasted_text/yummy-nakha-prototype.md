Create a polished, interactive, mobile-first web app prototype called YummyNaKha!

YummyNaKha! is a personalized Thai restaurant menu assistant for people who cannot easily read Thai menus.

The experience should be extremely simple:

Set My Taste once → Upload Thai menu images → Analyze → Get personalized English menu → Select dishes → Show selected dishes in Thai to restaurant staff

Build this as a functional clickable prototype, not just static screens.

⸻

1. BRAND

Product name:

YummyNaKha!

Tagline:

What’s yummy for you?

Create a youthful, modern, friendly Gen-Z food-app identity.

The design should feel:

* playful
* warm
* clean
* modern
* minimal
* friendly
* food-focused
* easy to use in a restaurant
* trustworthy for allergy warnings

Avoid:

* corporate dashboard styling
* overly medical styling
* excessive gradients
* cluttered interfaces
* too many colors
* tiny text
* complicated forms

Use:

* rounded cards
* rounded chips
* large touch targets
* clean typography
* subtle shadows
* generous whitespace
* friendly food icons
* subtle micro-interactions

Use a light theme.

⸻

2. MOBILE-FIRST

Design primarily for a mobile phone around 390px width.

It should also respond properly on larger screens.

The user will mainly use YummyNaKha! while sitting at a restaurant.

Create a persistent bottom navigation where appropriate:

Home | My Order | My Taste

Keep navigation minimal.

⸻

3. WELCOME / ONBOARDING

Create a friendly first screen.

Show:

YummyNaKha!

What’s yummy for you?

Supporting copy:

Upload a Thai menu. We’ll help you find food that fits your taste.

Primary button:

Get Started

Keep onboarding short.

Do NOT create a long multi-page questionnaire.

⸻

4. MY TASTE

This is the user’s food profile.

Title:

My Taste

Subtitle:

Tell us what you love and what you’d rather avoid.

Use ONE segmented control with TWO tabs:

❤️ Favs | 🚫 Avoid

Do not create separate pages for allergies, dietary restrictions, dislikes, doctor restrictions, etc.

⸻

5. FAVS TAB

When ❤️ Favs is selected, show:

Your Favs

Users can manually type ANY food, ingredient, flavor, or dish they like.

Input:

Add something you love…

Add a + button.

Example interactions:

User types:

Chicken

Tap +

Create chip:

Chicken ×

Then:

Cheese ×

Spicy ×

Banana ×

Noodles ×

Users must be able to:

* type custom words
* add them
* see them as chips
* remove them with ×
* save changes

Do NOT restrict users to predefined foods.

Optional suggestions may appear below the input, but manual input must always be supported.

Example:

❤️ Your Favs

[ Chicken × ] [ Cheese × ]

[ Spicy × ] [ Noodles × ]

[ Banana × ]

[ Add something you love… ] [+]

Button:

Save My Taste

⸻

6. AVOID TAB

When 🚫 Avoid is selected, allow users to manually enter anything they do not want.

Examples:

* Peanuts
* Pork
* Mushroom
* Seafood
* Very sweet

Input:

Add something to avoid…

After the user enters an item, open a small bottom sheet/modal:

Why do you avoid Peanuts?

Options:

Just don’t like it

⚠️ Allergy

🩺 Doctor advised

Also include:

Skip

The reason is OPTIONAL.

Do not force the user to classify everything.

Example saved Avoid list:

Peanuts — ⚠️ Allergy

Pork — 🩺 Doctor advised

Mushroom

Display these as clean chips/cards.

Allow edit and remove.

Button:

Save My Taste

⸻

7. RETURNING USER HOME

After setup, Home should be extremely simple.

Header:

YummyNaKha!

Greeting:

What are we eating today? 👀

Show a small summary:

Your Taste

❤️ Chicken · Cheese · Spicy · Noodles

🚫 Peanuts ⚠️ · Pork 🩺 · Mushroom

Small action:

Edit

Then make the PRIMARY feature visually dominant:

Upload a Thai Menu

Use a large upload card.

Icon/image placeholder.

Text:

Drop your menu here

or

Choose menu images

Support multiple images.

IMPORTANT:

This is image UPLOAD.

Do NOT create a live camera scanner interface.

Allow:

* upload image
* multiple images
* preview uploaded images
* remove image
* replace image
* add another image

Primary CTA after images are added:

Find My Food ✨

⸻

8. SAMPLE UPLOAD STATE

For the prototype, simulate two uploaded Thai menu images.

Show image thumbnails/cards.

Example:

menu-page-1.jpg

menu-page-2.jpg

Actions:

Remove

Add another

Then:

Find My Food ✨

Clicking this should move to the analysis screen.

⸻

9. ANALYZING SCREEN

Create a fun but clean loading experience.

Title:

Finding your yummy…

Animate through steps:

✓ Reading your Thai menu

✓ Finding dishes & prices

✓ Translating to English

✓ Checking your Favs

✓ Checking your Avoid list

→ Finding your best picks

Do not use a generic spinner alone.

After a short simulated state, allow the prototype to continue to results.

⸻

10. PERSONALIZED MENU

This is the MOST IMPORTANT SCREEN.

Title:

Your Menu

Subtitle:

Picked for your taste ✨

The menu was originally Thai, but dish information is now shown primarily in ENGLISH.

Keep the original Thai dish name underneath.

At the top, provide filter chips:

All

⭐ Top Picks

🟡 Check First

🔴 Avoid

Do not show a long AI response.

Use beautiful food/menu cards.

⸻

11. TOP PICKS

Example:

⭐ Top Pick

Chicken Basil Rice

กะเพราไก่

฿60

Show reasons:

❤️ Chicken

❤️ Spicy

Small label:

Matches your Favs

Button:

+ Select

Another:

Chicken Noodle Soup

ก๋วยเตี๋ยวไก่

฿55

❤️ Chicken

❤️ Noodles

+ Select

Do NOT use fake percentages such as:

96% match

or

99% safe.

Use understandable labels instead.

⸻

12. CHECK FIRST

Example:

🟡 Check First

Chicken Pad Thai

ผัดไทยไก่

฿70

❤️ Chicken

❤️ Noodles

Then clearly show:

⚠️ Peanuts are in your Avoid list

You marked Peanuts as an Allergy.

Supporting text:

Peanuts may commonly be served with this dish. Please confirm with restaurant staff before ordering.

Button:

View Details

Button:

+ Select

Use yellow/amber warning styling.

Do NOT claim that peanuts are definitely present unless the menu explicitly says so.

⸻

13. AVOID

Example:

🔴 Avoid

Pork Fried Rice

ข้าวผัดหมู

฿60

Reason:

🩺 Pork is in your Avoid list

Doctor advised you to avoid it.

Another example:

Mushroom Pork Stir Fry

ผัดเห็ดหมู

฿70

🚫 Mushroom

🩺 Pork

Use clear red styling without making the interface scary.

⸻

14. SAFETY UX

This is extremely important.

Never display:

SAFE

100% SAFE

ALLERGY FREE

or any similar certainty.

YummyNaKha! only analyzes information available from the menu and common dish information.

Menu photos cannot confirm:

* hidden ingredients
* sauces
* cooking oil
* garnishes
* cross-contact
* kitchen preparation

Use wording such as:

No detected conflict from the available menu information.

For uncertainty use:

Check with restaurant staff before ordering.

Include a small information icon that opens:

About food warnings

Text:

YummyNaKha! helps identify possible food conflicts from menu information, but restaurant ingredients and preparation can vary. Always confirm serious allergies or medical restrictions with restaurant staff.

⸻

15. DISH DETAILS

Clicking a menu card should open a detailed page or bottom sheet.

Example:

Chicken Pad Thai

ผัดไทยไก่

฿70

Why you might like it

❤️ Chicken — in your Favs

❤️ Noodles — in your Favs

Check before ordering

⚠️ Peanuts

You marked this as an Allergy.

Explain:

Peanuts may commonly be served with Pad Thai, but the menu does not confirm whether this restaurant uses them.

Button:

Add to My Order

⸻

16. SELECTING FOOD

Users can select multiple dishes.

When selected, change:

+ Select

to:

✓ Selected

Show a sticky bottom bar when at least one dish is selected:

2 dishes selected

View My Order →

Make this interaction work in the prototype.

⸻

17. MY ORDER — ENGLISH

When the user taps View My Order, open:

My Order

Subtitle:

Check your picks

Show selected items:

Chicken Basil Rice

กะเพราไก่

฿60

Remove

Chicken Pad Thai

ผัดไทยไก่

฿70

Remove

Then:

2 dishes

Total: ฿130

Provide:

← Add More

Primary CTA:

Show in Thai

The purpose of this button is to prepare a simple screen that the customer can show directly to restaurant staff.

⸻

18. SHOW IN THAI

This screen should be very simple and highly readable.

Do NOT show recommendation information here.

Do NOT show allergy analysis.

Do NOT show Favs.

The restaurant staff only needs to understand what the customer selected.

Title:

รายการที่ต้องการสั่ง

Large cards/text:

กะเพราไก่

60 บาท

ผัดไทยไก่

70 บาท

Bottom:

รวม 130 บาท

Provide a small button:

← Back to English

Make Thai text large enough to show across a table to restaurant staff.

No voice output.

⸻

19. MY TASTE — RETURNING USER

From bottom navigation, users can always open:

My Taste

Tabs:

❤️ Favs | 🚫 Avoid

Allow them to:

* add custom words
* delete words
* change Avoid reason
* save

The profile persists in the prototype.

⸻

20. DEMO USER DATA

Use this saved profile throughout the prototype:

❤️ Favs

Chicken

Cheese

Spicy

Noodles

Banana

🚫 Avoid

Peanuts — ⚠️ Allergy

Pork — 🩺 Doctor advised

Mushroom — normal avoid

⸻

21. SAMPLE MENU DATA

Use realistic sample Thai dishes:

กะเพราไก่
Chicken Basil Rice
฿60

ผัดไทยไก่
Chicken Pad Thai
฿70

ข้าวผัดหมู
Pork Fried Rice
฿60

ก๋วยเตี๋ยวไก่
Chicken Noodles
฿55

กะเพราหมูกรอบ
Crispy Pork Basil Rice
฿65

ข้าวผัดกุ้ง
Shrimp Fried Rice
฿75

ผัดเห็ดไก่
Chicken with Mushrooms
฿70

Use enough sample dishes to demonstrate filtering and personalization.

⸻

22. INTERACTION FLOW

Make this entire flow clickable:

Welcome

↓

My Taste

↓

Add Favs

↓

Add Avoid items

↓

Save

↓

Home

↓

Upload menu images

↓

Find My Food

↓

Analyzing

↓

Personalized Menu

↓

Filter recommendations

↓

Select dishes

↓

View My Order

↓

English selected-menu page

↓

Show in Thai

↓

Thai restaurant-facing order page

Also make:

Home | My Order | My Taste

navigation functional.

⸻

23. UX PRINCIPLE

The most important principle is:

Minimal effort at the restaurant.

The user sets their taste profile beforehand.

At the restaurant they should only need:

Upload → Pick → Show

Do not introduce unnecessary questions during the restaurant flow.

Do not ask them to re-enter allergies or favorites.

Do not require restaurant selection.

Do not require restaurant registration.

Do not require restaurant data.

Do not require account creation during the restaurant flow.

⸻

24. PRODUCT POSITIONING

YummyNaKha! is NOT simply a Thai menu translator.

Google Translate already translates menus.

The value is:

Thai Menu Image

My Favs

My Avoid List

↓

Personalized English Menu

↓

Choose Food

↓

Show Order in Thai

The UI should make this personalization obvious.

⸻

25. FINAL QUALITY

Do not make this look like a student CRUD project.

Make it look like a polished consumer food app that Gen-Z international students in Thailand would actually want to use.

Prioritize:

1. Simplicity
2. Fast restaurant usage
3. Clear personalization
4. Excellent mobile UX
5. Clear allergy warnings
6. Fun YummyNaKha! branding
7. Beautiful menu cards
8. Smooth interactions

Build the complete high-fidelity interactive prototype now.