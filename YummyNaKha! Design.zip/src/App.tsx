import { useState, useEffect } from 'react';
import {
  UtensilsCrossed,
  Heart,
  Ban,
  Home as HomeIcon,
  ShoppingBag,
  Camera,
  Plus,
  X,
  ChevronRight,
  Star,
  AlertTriangle,
  Stethoscope,
  Info,
  Check,
  ArrowLeft,
  Trash2,
  Loader2,
  ScanLine,
  Languages,
  ListChecks,
  SearchCheck,
  Sparkles,
  CookingPot,
  Fish,
  Beef,
  Leaf,
  Soup,
  Flame,
  ShoppingCart,
  Mail,
  Lock,
  Eye,
  EyeOff,
  CircleUser,
  KeyRound,
  ChevronLeft,
  LogOut,
} from 'lucide-react';

// ─── Types ────────────────────────────────────────────────────────────────────

type Screen =
  | 'welcome'
  | 'signin'
  | 'signup'
  | 'forgot'
  | 'taste'
  | 'home'
  | 'analyzing'
  | 'menu'
  | 'order'
  | 'thai'
  | 'profile'
  | 'changepassword';

interface AppUser {
  name: string;
  email: string;
}
type AvoidReason = 'dislike' | 'allergy' | 'doctor';
type MenuFilter = 'all' | 'top' | 'check' | 'avoid';

interface AvoidItem {
  name: string;
  reason?: AvoidReason;
}

interface TasteProfile {
  favs: string[];
  avoid: AvoidItem[];
}

interface ConflictItem {
  name: string;
  reason?: AvoidReason;
  note: string;
}

interface Dish {
  id: string;
  nameThai: string;
  nameEn: string;
  price: number;
  status: 'top' | 'check' | 'avoid';
  favMatches: string[];
  conflicts: ConflictItem[];
  Icon: React.FC<{ size?: number; className?: string }>;
  bg: string;
  iconColor: string;
}

// ─── Static Data ──────────────────────────────────────────────────────────────

const DEFAULT_PROFILE: TasteProfile = {
  favs: ['Chicken', 'Cheese', 'Spicy', 'Noodles', 'Banana'],
  avoid: [
    { name: 'Peanuts', reason: 'allergy' },
    { name: 'Pork', reason: 'doctor' },
    { name: 'Mushroom', reason: 'dislike' },
  ],
};

const DISHES: Dish[] = [
  {
    id: '1',
    nameThai: 'กะเพราไก่',
    nameEn: 'Chicken Basil Rice',
    price: 60,
    status: 'top',
    favMatches: ['Chicken', 'Spicy'],
    conflicts: [],
    Icon: Flame,
    bg: '#FFF7ED',
    iconColor: '#EA580C',
  },
  {
    id: '2',
    nameThai: 'ผัดไทยไก่',
    nameEn: 'Chicken Pad Thai',
    price: 70,
    status: 'check',
    favMatches: ['Chicken', 'Noodles'],
    conflicts: [
      {
        name: 'Peanuts',
        reason: 'allergy',
        note: 'Peanuts are commonly served with Pad Thai. Please confirm with restaurant staff before ordering.',
      },
    ],
    Icon: CookingPot,
    bg: '#FFFBEB',
    iconColor: '#D97706',
  },
  {
    id: '3',
    nameThai: 'ข้าวผัดหมู',
    nameEn: 'Pork Fried Rice',
    price: 60,
    status: 'avoid',
    favMatches: [],
    conflicts: [
      {
        name: 'Pork',
        reason: 'doctor',
        note: 'This dish contains pork, which is in your Avoid list.',
      },
    ],
    Icon: Beef,
    bg: '#FFF1F2',
    iconColor: '#E11D48',
  },
  {
    id: '4',
    nameThai: 'ก๋วยเตี๋ยวไก่',
    nameEn: 'Chicken Noodle Soup',
    price: 55,
    status: 'top',
    favMatches: ['Chicken', 'Noodles'],
    conflicts: [],
    Icon: Soup,
    bg: '#F0FDF4',
    iconColor: '#16A34A',
  },
  {
    id: '5',
    nameThai: 'กะเพราหมูกรอบ',
    nameEn: 'Crispy Pork Basil Rice',
    price: 65,
    status: 'avoid',
    favMatches: [],
    conflicts: [
      {
        name: 'Pork',
        reason: 'doctor',
        note: 'This dish contains pork, which is in your Avoid list.',
      },
    ],
    Icon: Beef,
    bg: '#FFF1F2',
    iconColor: '#E11D48',
  },
  {
    id: '6',
    nameThai: 'ข้าวผัดกุ้ง',
    nameEn: 'Shrimp Fried Rice',
    price: 75,
    status: 'top',
    favMatches: ['Spicy'],
    conflicts: [],
    Icon: Fish,
    bg: '#FDF4FF',
    iconColor: '#9333EA',
  },
  {
    id: '7',
    nameThai: 'ผัดเห็ดไก่',
    nameEn: 'Chicken with Mushrooms',
    price: 70,
    status: 'check',
    favMatches: ['Chicken'],
    conflicts: [
      {
        name: 'Mushroom',
        reason: 'dislike',
        note: 'This dish contains mushrooms, which are in your Avoid list.',
      },
    ],
    Icon: Leaf,
    bg: '#FFFBEB',
    iconColor: '#65A30D',
  },
];

// ─── Helpers ──────────────────────────────────────────────────────────────────

function ReasonIcon({ reason, size = 14 }: { reason?: AvoidReason; size?: number }) {
  if (reason === 'allergy') return <AlertTriangle size={size} className="shrink-0" style={{ color: '#B45309' }} />;
  if (reason === 'doctor') return <Stethoscope size={size} className="shrink-0" style={{ color: '#1D4ED8' }} />;
  return null;
}

function reasonLabel(r?: AvoidReason) {
  if (r === 'allergy') return 'Allergy';
  if (r === 'doctor') return 'Doctor advised';
  return 'Just avoid';
}

const STATUS = {
  top: { label: 'Top Pick', bg: '#ECFDF5', text: '#065F46', Icon: Star },
  check: { label: 'Check First', bg: '#FFFBEB', text: '#92400E', Icon: AlertTriangle },
  avoid: { label: 'Avoid', bg: '#FEF2F2', text: '#991B1B', Icon: Ban },
};

// ─── Welcome ──────────────────────────────────────────────────────────────────

function Welcome({ onStart }: { onStart: () => void }) {
  return (
    <div
      className="flex flex-col min-h-screen px-6 py-16 items-center justify-between"
      style={{ background: 'linear-gradient(170deg,#FFF5EC 0%,#FFFBF7 55%,#F0FDF4 100%)' }}
    >
      <div />
      <div className="flex flex-col items-center text-center w-full max-w-xs">
        <div
          className="w-20 h-20 rounded-3xl flex items-center justify-center mb-6 shadow-md"
          style={{ background: '#FF6542' }}
        >
          <UtensilsCrossed size={36} color="#fff" strokeWidth={2} />
        </div>

        <h1 className="text-[2.75rem] font-black text-[#1C1917] tracking-tight leading-none mb-2">
          YummyNaKha!
        </h1>
        <p className="font-bold text-lg mb-8" style={{ color: '#FF6542' }}>
          What's yummy for you?
        </p>

        <div className="w-full rounded-3xl bg-white shadow-sm p-5 mb-8">
          <p className="text-[#4A4440] text-[15px] leading-relaxed">
            Upload a Thai menu. We'll help you find food that fits your taste.
          </p>
        </div>

        <div className="flex flex-col gap-3.5 w-full mb-10 text-left">
          {(
            [
              { Icon: Heart, text: 'Set your food preferences once', color: '#FF6542' },
              { Icon: Camera, text: 'Upload any Thai menu photo', color: '#8B5CF6' },
              { Icon: Sparkles, text: 'Get personalized picks in English', color: '#F59E0B' },
              { Icon: Languages, text: 'Show your order in Thai to staff', color: '#10B981' },
            ] as { Icon: React.FC<{ size: number; color: string }>; text: string; color: string }[]
          ).map(({ Icon: FeatureIcon, text, color }) => (
            <div key={text} className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0"
                style={{ background: `${color}18` }}
              >
                <FeatureIcon size={16} color={color} />
              </div>
              <span className="text-sm font-semibold text-[#4A4440]">{text}</span>
            </div>
          ))}
        </div>

        <button
          onClick={onStart}
          className="w-full py-4 rounded-2xl text-white font-black text-lg shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2"
          style={{ background: '#FF6542' }}
        >
          Get Started
          <ChevronRight size={20} strokeWidth={3} />
        </button>
      </div>
      <div />
    </div>
  );
}

// ─── My Taste ─────────────────────────────────────────────────────────────────

function MyTaste({
  profile,
  setProfile,
  onSave,
  showNav,
}: {
  profile: TasteProfile;
  setProfile: (p: TasteProfile) => void;
  onSave: () => void;
  showNav: boolean;
}) {
  const [tab, setTab] = useState<'favs' | 'avoid'>('favs');
  const [favInput, setFavInput] = useState('');
  const [avoidInput, setAvoidInput] = useState('');
  const [reasonModal, setReasonModal] = useState<string | null>(null);

  const FAV_SUGGESTIONS = ['Spicy', 'Sweet', 'Sour', 'Beef', 'Seafood', 'Tofu', 'Rice', 'Veggie', 'Mild'];

  function addFav() {
    const v = favInput.trim();
    if (!v || profile.favs.map(f => f.toLowerCase()).includes(v.toLowerCase())) return;
    setProfile({ ...profile, favs: [...profile.favs, v] });
    setFavInput('');
  }

  function removeFav(name: string) {
    setProfile({ ...profile, favs: profile.favs.filter(f => f !== name) });
  }

  function openAvoidModal() {
    const v = avoidInput.trim();
    if (!v) return;
    setReasonModal(v);
  }

  function saveAvoid(reason?: AvoidReason) {
    if (!reasonModal) return;
    if (!profile.avoid.find(a => a.name.toLowerCase() === reasonModal.toLowerCase())) {
      setProfile({ ...profile, avoid: [...profile.avoid, { name: reasonModal, reason }] });
    }
    setReasonModal(null);
    setAvoidInput('');
  }

  function removeAvoid(name: string) {
    setProfile({ ...profile, avoid: profile.avoid.filter(a => a.name !== name) });
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7]">
      <div className="px-5 pt-14 pb-4">
        <h1 className="text-2xl font-black text-[#1C1917]">My Taste</h1>
        <p className="text-[#78716C] text-sm mt-0.5">Tell us what you love and what you'd rather avoid.</p>
      </div>

      <div className="px-5 mb-4">
        <div className="flex rounded-2xl p-1 gap-1" style={{ background: '#F0EBE3' }}>
          {([
            { key: 'favs', label: 'Favs', Icon: Heart },
            { key: 'avoid', label: 'Avoid', Icon: Ban },
          ] as { key: 'favs' | 'avoid'; label: string; Icon: React.FC<{ size: number; className?: string }> }[]).map(t => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`flex-1 py-2.5 rounded-xl text-sm font-bold transition-all flex items-center justify-center gap-1.5 ${
                tab === t.key ? 'bg-white shadow-sm text-[#FF6542]' : 'text-[#78716C]'
              }`}
            >
              <t.Icon size={14} className={tab === t.key ? 'text-[#FF6542]' : 'text-[#78716C]'} />
              {t.label}
            </button>
          ))}
        </div>
      </div>

      <div
        className="flex-1 overflow-y-auto px-5"
        style={{ paddingBottom: showNav ? '9rem' : '7rem' }}
      >
        {tab === 'favs' && (
          <div>
            <h2 className="text-sm font-bold text-[#1C1917] mb-3 flex items-center gap-1.5">
              <Heart size={14} style={{ color: '#FF6542' }} />
              Your Favs
            </h2>

            <div className="flex flex-wrap gap-2 mb-5">
              {profile.favs.map(fav => (
                <span
                  key={fav}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-bold"
                  style={{ background: '#FFE8E0', color: '#FF6542' }}
                >
                  {fav}
                  <button onClick={() => removeFav(fav)} className="ml-0.5 hover:opacity-70 flex items-center">
                    <X size={12} strokeWidth={3} />
                  </button>
                </span>
              ))}
            </div>

            <div className="flex gap-2 mb-5">
              <input
                type="text"
                value={favInput}
                onChange={e => setFavInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && addFav()}
                placeholder="Add something you love…"
                className="flex-1 rounded-xl px-4 py-3 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
              />
              <button
                onClick={addFav}
                className="w-12 h-12 rounded-xl text-white flex items-center justify-center shrink-0"
                style={{ background: '#FF6542' }}
              >
                <Plus size={22} strokeWidth={2.5} />
              </button>
            </div>

            <p className="text-xs font-bold text-[#A8A29E] uppercase tracking-wider mb-2">Suggestions</p>
            <div className="flex flex-wrap gap-2">
              {FAV_SUGGESTIONS.filter(
                s => !profile.favs.map(f => f.toLowerCase()).includes(s.toLowerCase())
              ).map(s => (
                <button
                  key={s}
                  onClick={() => setProfile({ ...profile, favs: [...profile.favs, s] })}
                  className="flex items-center gap-1 px-3 py-1.5 rounded-full text-sm font-semibold border border-[#EDE8E1] text-[#78716C] hover:border-[#FF6542] hover:text-[#FF6542] transition-colors"
                >
                  <Plus size={12} strokeWidth={2.5} />
                  {s}
                </button>
              ))}
            </div>
          </div>
        )}

        {tab === 'avoid' && (
          <div>
            <h2 className="text-sm font-bold text-[#1C1917] mb-3 flex items-center gap-1.5">
              <Ban size={14} style={{ color: '#FF6542' }} />
              Your Avoid List
            </h2>

            <div className="flex flex-col gap-2 mb-5">
              {profile.avoid.map(item => (
                <div
                  key={item.name}
                  className="flex items-center justify-between px-4 py-3 rounded-2xl bg-white border border-[#EDE8E1]"
                >
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-sm font-bold text-[#1C1917]">{item.name}</span>
                    {item.reason && (
                      <span
                        className="flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-semibold"
                        style={{
                          background:
                            item.reason === 'allergy'
                              ? '#FEF3C7'
                              : item.reason === 'doctor'
                              ? '#EFF6FF'
                              : '#F5F0E8',
                          color:
                            item.reason === 'allergy'
                              ? '#92400E'
                              : item.reason === 'doctor'
                              ? '#1E40AF'
                              : '#78716C',
                        }}
                      >
                        <ReasonIcon reason={item.reason} size={11} />
                        {reasonLabel(item.reason)}
                      </span>
                    )}
                  </div>
                  <button
                    onClick={() => removeAvoid(item.name)}
                    className="text-[#C4BBB4] hover:text-[#EF4444] transition-colors ml-2 flex items-center"
                  >
                    <X size={16} />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex gap-2">
              <input
                type="text"
                value={avoidInput}
                onChange={e => setAvoidInput(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && openAvoidModal()}
                placeholder="Add something to avoid…"
                className="flex-1 rounded-xl px-4 py-3 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
              />
              <button
                onClick={openAvoidModal}
                className="w-12 h-12 rounded-xl text-white flex items-center justify-center shrink-0"
                style={{ background: '#1C1917' }}
              >
                <Plus size={22} strokeWidth={2.5} />
              </button>
            </div>
          </div>
        )}
      </div>

      <div
        className="fixed left-1/2 -translate-x-1/2 w-full max-w-[430px] px-5 pt-4 pb-6 bg-gradient-to-t from-[#FFFBF7] via-[#FFFBF7]"
        style={{ bottom: showNav ? '4rem' : '0' }}
      >
        <button
          onClick={onSave}
          className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2"
          style={{ background: '#FF6542' }}
        >
          <Check size={18} strokeWidth={3} />
          Save My Taste
        </button>
      </div>

      {reasonModal && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          style={{ background: 'rgba(0,0,0,0.45)' }}
        >
          <div className="w-full max-w-[430px] mx-auto rounded-t-3xl bg-white px-5 pt-5 pb-10">
            <div className="w-10 h-1 rounded-full bg-[#EDE8E1] mx-auto mb-5" />
            <h3 className="text-lg font-black text-[#1C1917] mb-1">
              Why do you avoid{' '}
              <span style={{ color: '#FF6542' }}>{reasonModal}</span>?
            </h3>
            <p className="text-sm text-[#78716C] mb-5">
              Optional — helps us give you better warnings.
            </p>
            <div className="flex flex-col gap-3">
              {([
                { reason: 'dislike' as AvoidReason, label: "Just don't like it", Icon: Ban, color: '#78716C', bg: '#F5F0E8' },
                { reason: 'allergy' as AvoidReason, label: 'Allergy', Icon: AlertTriangle, color: '#92400E', bg: '#FEF3C7' },
                { reason: 'doctor' as AvoidReason, label: 'Doctor advised', Icon: Stethoscope, color: '#1E40AF', bg: '#EFF6FF' },
              ]).map(({ reason, label, Icon: ModalIcon, color, bg }) => (
                <button
                  key={reason}
                  onClick={() => saveAvoid(reason)}
                  className="flex items-center gap-3 px-5 py-4 rounded-2xl border border-[#EDE8E1] text-left font-bold text-[#1C1917] hover:border-[#FF6542] transition-colors"
                >
                  <div className="w-8 h-8 rounded-xl flex items-center justify-center shrink-0" style={{ background: bg }}>
                    <ModalIcon size={16} style={{ color }} />
                  </div>
                  {label}
                </button>
              ))}
              <button
                onClick={() => saveAvoid(undefined)}
                className="py-3 text-sm font-semibold text-[#A8A29E] underline"
              >
                Skip
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Home ─────────────────────────────────────────────────────────────────────

function Home({
  profile,
  user,
  onFindFood,
  onEditTaste,
  onProfile,
}: {
  profile: TasteProfile;
  user: AppUser;
  onFindFood: () => void;
  onEditTaste: () => void;
  onProfile: () => void;
}) {
  const [images, setImages] = useState(['menu-page-1.jpg', 'menu-page-2.jpg']);

  function removeImage(i: number) {
    setImages(prev => prev.filter((_, idx) => idx !== i));
  }

  function addImage() {
    setImages(prev => [...prev, `menu-page-${prev.length + 1}.jpg`]);
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7] pb-28">
      <div className="px-5 pt-14 pb-5 flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-black" style={{ color: '#FF6542' }}>YummyNaKha!</h1>
          <p className="text-xl font-black text-[#1C1917] mt-0.5">What are we eating today?</p>
        </div>
        <button
          onClick={onProfile}
          className="w-10 h-10 rounded-full flex items-center justify-center text-sm font-black text-white shadow-sm mt-1 shrink-0"
          style={{ background: '#FF6542' }}
        >
          {(user?.name ?? 'YN').slice(0, 2).toUpperCase()}
        </button>
      </div>

      <div className="mx-5 mb-5 rounded-2xl bg-white border border-[#EDE8E1] p-4 shadow-sm">
        <div className="flex justify-between items-center mb-2">
          <span className="text-xs font-black text-[#A8A29E] uppercase tracking-wider">Your Taste</span>
          <button
            onClick={onEditTaste}
            className="text-xs font-bold"
            style={{ color: '#FF6542' }}
          >
            Edit
          </button>
        </div>
        <div className="flex items-start gap-2 mb-1.5">
          <Heart size={14} className="shrink-0 mt-0.5" style={{ color: '#FF6542' }} />
          <p className="text-sm font-semibold text-[#1C1917] leading-snug">
            {profile.favs.join(' · ')}
          </p>
        </div>
        <div className="flex items-start gap-2">
          <Ban size={14} className="shrink-0 mt-0.5" style={{ color: '#EF4444' }} />
          <p className="text-sm font-semibold text-[#1C1917] leading-snug">
            {profile.avoid
              .map(a => a.name + (a.reason === 'allergy' ? ' (Allergy)' : a.reason === 'doctor' ? ' (Dr.)' : ''))
              .join(' · ')}
          </p>
        </div>
      </div>

      <div className="px-5">
        <h2 className="text-base font-black text-[#1C1917] mb-3">Upload a Thai Menu</h2>

        {images.length === 0 ? (
          <button
            onClick={addImage}
            className="w-full border-2 border-dashed border-[#EDE8E1] rounded-3xl py-14 flex flex-col items-center gap-3 hover:border-[#FF6542] transition-colors"
          >
            <div className="w-14 h-14 rounded-2xl flex items-center justify-center" style={{ background: '#FFF0E8' }}>
              <Camera size={28} style={{ color: '#FF6542' }} />
            </div>
            <div className="text-center">
              <p className="text-[#1C1917] font-bold text-base">Drop your menu here</p>
              <p className="text-[#A8A29E] text-xs mt-0.5">or tap to choose menu images</p>
            </div>
          </button>
        ) : (
          <div className="flex flex-col gap-3">
            {images.map((img, i) => (
              <div
                key={img + i}
                className="flex items-center gap-3 bg-white rounded-2xl p-3 border border-[#EDE8E1] shadow-sm"
              >
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: '#FFF0E8' }}
                >
                  <ScanLine size={24} style={{ color: '#FF6542' }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-bold text-[#1C1917] truncate">{img}</p>
                  <p className="text-xs font-semibold mt-0.5 flex items-center gap-1" style={{ color: '#10B981' }}>
                    <Check size={11} strokeWidth={3} />
                    Ready to analyze
                  </p>
                </div>
                <button
                  onClick={() => removeImage(i)}
                  className="text-[#C4BBB4] hover:text-[#EF4444] transition-colors p-1 flex items-center"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            ))}

            <button
              onClick={addImage}
              className="flex items-center justify-center gap-2 py-3.5 rounded-2xl border-2 border-dashed border-[#EDE8E1] text-sm font-bold text-[#78716C] hover:border-[#FF6542] hover:text-[#FF6542] transition-colors"
            >
              <Plus size={16} strokeWidth={2.5} />
              Add another
            </button>

            <button
              onClick={onFindFood}
              className="w-full py-4 rounded-2xl text-white font-black text-base shadow-lg active:scale-95 transition-transform flex items-center justify-center gap-2 mt-1"
              style={{ background: '#FF6542' }}
            >
              <Sparkles size={18} />
              Find My Food
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ─── Analyzing ────────────────────────────────────────────────────────────────

const STEPS: { label: string; Icon: React.FC<{ size: number; className?: string }> }[] = [
  { label: 'Reading your Thai menu', Icon: ScanLine },
  { label: 'Finding dishes & prices', Icon: ListChecks },
  { label: 'Translating to English', Icon: Languages },
  { label: 'Checking your Favs', Icon: Heart },
  { label: 'Checking your Avoid list', Icon: Ban },
  { label: 'Finding your best picks', Icon: SearchCheck },
];

function Analyzing({ onDone }: { onDone: () => void }) {
  const [step, setStep] = useState(0);

  useEffect(() => {
    if (step < STEPS.length) {
      const t = setTimeout(() => setStep(s => s + 1), 650);
      return () => clearTimeout(t);
    }
    const t = setTimeout(onDone, 700);
    return () => clearTimeout(t);
  }, [step]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-[#FFFBF7] px-8">
      <div
        className="w-20 h-20 rounded-3xl flex items-center justify-center mb-8 shadow-md"
        style={{ background: '#FF6542' }}
      >
        <Loader2 size={36} color="#fff" className="animate-spin" />
      </div>
      <h1 className="text-2xl font-black text-[#1C1917] text-center mb-10">
        Finding your yummy…
      </h1>

      <div className="w-full max-w-xs flex flex-col gap-3.5">
        {STEPS.map((s, i) => {
          const visible = i < step;
          const isLast = i === STEPS.length - 1;
          return (
            <div
              key={s.label}
              className="flex items-center gap-3 transition-all duration-500"
              style={{
                opacity: visible ? 1 : 0,
                transform: visible ? 'translateX(0)' : 'translateX(16px)',
              }}
            >
              <div
                className="w-6 h-6 rounded-full shrink-0 flex items-center justify-center transition-all duration-300"
                style={{
                  background: visible ? (isLast ? '#FF6542' : '#10B981') : '#EDE8E1',
                }}
              >
                {visible && (
                  isLast
                    ? <Sparkles size={12} color="#fff" />
                    : <Check size={12} color="#fff" strokeWidth={3} />
                )}
              </div>
              <span
                className="text-sm font-bold"
                style={{ color: visible ? (isLast ? '#FF6542' : '#1C1917') : '#EDE8E1' }}
              >
                {s.label}
              </span>
            </div>
          );
        })}
      </div>

      <div
        className="mt-10 w-full max-w-xs rounded-full overflow-hidden"
        style={{ height: '4px', background: '#EDE8E1' }}
      >
        <div
          className="h-full rounded-full transition-all duration-700"
          style={{ width: `${(step / STEPS.length) * 100}%`, background: '#FF6542' }}
        />
      </div>
    </div>
  );
}

// ─── Dish Card ────────────────────────────────────────────────────────────────

function DishCard({
  dish,
  selected,
  onSelect,
  onOpen,
}: {
  dish: Dish;
  selected: boolean;
  onSelect: () => void;
  onOpen: () => void;
}) {
  const st = STATUS[dish.status];
  const StatusIcon = st.Icon;
  const DishIcon = dish.Icon;

  return (
    <div
      className="rounded-2xl border p-4 cursor-pointer active:scale-[0.99] transition-all"
      style={{
        background: selected
          ? (dish.status === 'top' ? '#DCFCE7' : dish.status === 'check' ? '#FEF9C3' : '#FFE4E6')
          : (dish.status === 'top' ? '#F0FDF4' : dish.status === 'check' ? '#FEFCE8' : '#FFF1F2'),
        borderColor: selected ? '#FF6542' : (dish.status === 'top' ? '#BBF7D0' : dish.status === 'check' ? '#FDE68A' : '#FECDD3'),
        boxShadow: selected ? '0 0 0 2px #FF654230' : '0 1px 3px rgba(0,0,0,0.04)',
      }}
      onClick={onOpen}
    >
      <div className="flex items-start gap-3">
        <div
          className="w-14 h-14 rounded-xl flex items-center justify-center shrink-0"
          style={{ background: dish.bg }}
        >
          <DishIcon size={26} style={{ color: dish.iconColor }} />
        </div>
        <div className="flex-1 min-w-0">
          <span
            className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full mb-1.5"
            style={{ background: st.bg, color: st.text }}
          >
            <StatusIcon size={10} strokeWidth={2.5} />
            {st.label}
          </span>
          <h3 className="font-black text-[#1C1917] text-base leading-tight">{dish.nameEn}</h3>
          <p className="text-sm font-medium text-[#A8A29E] font-thai">{dish.nameThai}</p>
          <p className="text-sm font-black mt-0.5" style={{ color: '#FF6542' }}>
            ฿{dish.price}
          </p>

          {dish.favMatches.length > 0 && (
            <div className="flex flex-wrap gap-1 mt-2">
              {dish.favMatches.map(f => (
                <span
                  key={f}
                  className="inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full font-bold"
                  style={{ background: '#FFE8E0', color: '#FF6542' }}
                >
                  <Heart size={9} strokeWidth={3} />
                  {f}
                </span>
              ))}
            </div>
          )}

          {dish.conflicts.length > 0 && (
            <div className="mt-2 flex flex-col gap-0.5">
              {dish.conflicts.map(c => (
                <p
                  key={c.name}
                  className="text-xs font-bold flex items-center gap-1"
                  style={{
                    color:
                      c.reason === 'allergy'
                        ? '#B45309'
                        : c.reason === 'doctor'
                        ? '#1D4ED8'
                        : '#78716C',
                  }}
                >
                  <ReasonIcon reason={c.reason} size={11} />
                  {c.name} in your Avoid list
                </p>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="mt-3 flex gap-2" onClick={e => e.stopPropagation()}>
        <button
          onClick={onOpen}
          className="flex-1 py-2.5 rounded-xl text-sm font-bold border border-[#EDE8E1] text-[#78716C] hover:border-[#FF6542] hover:text-[#FF6542] transition-colors"
        >
          View Details
        </button>
        <button
          onClick={onSelect}
          className="flex-1 py-2.5 rounded-xl text-sm font-black text-white transition-colors active:scale-95 flex items-center justify-center gap-1.5"
          style={{ background: selected ? '#10B981' : '#FF6542' }}
        >
          {selected ? (
            <>
              <Check size={14} strokeWidth={3} />
              Selected
            </>
          ) : (
            <>
              <Plus size={14} strokeWidth={2.5} />
              Select
            </>
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Dish Detail ──────────────────────────────────────────────────────────────

function DishDetail({
  dish,
  selected,
  onSelect,
  onClose,
}: {
  dish: Dish;
  selected: boolean;
  onSelect: () => void;
  onClose: () => void;
}) {
  const st = STATUS[dish.status];
  const StatusIcon = st.Icon;
  const DishIcon = dish.Icon;

  return (
    <div
      className="fixed inset-0 z-50 flex items-end"
      style={{ background: 'rgba(0,0,0,0.5)' }}
      onClick={onClose}
    >
      <div
        className="w-full max-w-[430px] mx-auto rounded-t-3xl bg-white px-5 pt-5 pb-10 overflow-y-auto"
        style={{ maxHeight: '85vh' }}
        onClick={e => e.stopPropagation()}
      >
        <div className="w-10 h-1 rounded-full bg-[#EDE8E1] mx-auto mb-5" />

        <div className="flex items-center gap-4 mb-5">
          <div
            className="w-20 h-20 rounded-2xl flex items-center justify-center shrink-0"
            style={{ background: dish.bg }}
          >
            <DishIcon size={36} style={{ color: dish.iconColor }} />
          </div>
          <div>
            <span
              className="inline-flex items-center gap-1 text-xs font-bold px-2.5 py-0.5 rounded-full mb-1.5"
              style={{ background: st.bg, color: st.text }}
            >
              <StatusIcon size={10} strokeWidth={2.5} />
              {st.label}
            </span>
            <h2 className="text-xl font-black text-[#1C1917] leading-tight">{dish.nameEn}</h2>
            <p className="text-base font-medium text-[#A8A29E] font-thai">{dish.nameThai}</p>
            <p className="text-lg font-black" style={{ color: '#FF6542' }}>฿{dish.price}</p>
          </div>
        </div>

        {dish.favMatches.length > 0 && (
          <div className="mb-4 p-4 rounded-2xl" style={{ background: '#F0FDF4' }}>
            <h3 className="text-sm font-black text-[#065F46] mb-2 flex items-center gap-1.5">
              <Heart size={13} style={{ color: '#065F46' }} />
              Why you might like it
            </h3>
            {dish.favMatches.map(f => (
              <div key={f} className="flex items-center gap-2 text-sm text-[#1C1917] mb-0.5">
                <Heart size={12} style={{ color: '#FF6542' }} />
                <span className="font-bold">{f}</span>
                <span className="text-[#A8A29E]">— in your Favs</span>
              </div>
            ))}
          </div>
        )}

        {dish.conflicts.length > 0 && (
          <div
            className="mb-4 p-4 rounded-2xl"
            style={{ background: dish.status === 'avoid' ? '#FEF2F2' : '#FFFBEB' }}
          >
            <h3
              className="text-sm font-black mb-2 flex items-center gap-1.5"
              style={{ color: dish.status === 'avoid' ? '#991B1B' : '#92400E' }}
            >
              <AlertTriangle size={13} />
              Check before ordering
            </h3>
            {dish.conflicts.map(c => (
              <div key={c.name} className="mb-3 last:mb-0">
                <div className="flex items-center gap-1.5 mb-1">
                  <ReasonIcon reason={c.reason} />
                  <span className="font-black text-sm text-[#1C1917]">{c.name}</span>
                  {c.reason && (
                    <span className="text-xs text-[#78716C] font-medium">
                      — {reasonLabel(c.reason)}
                    </span>
                  )}
                </div>
                <p className="text-xs text-[#78716C] leading-relaxed ml-5">{c.note}</p>
              </div>
            ))}
          </div>
        )}

        {dish.status === 'top' && (
          <div className="mb-4 p-3.5 rounded-2xl border border-[#EDE8E1] flex gap-2">
            <Info size={14} className="shrink-0 mt-0.5" style={{ color: '#78716C' }} />
            <p className="text-xs text-[#78716C] leading-relaxed">
              No detected conflict from the available menu information. Always confirm serious allergies or medical restrictions with restaurant staff.
            </p>
          </div>
        )}

        <button
          onClick={() => { onSelect(); onClose(); }}
          className="w-full py-4 rounded-2xl font-black text-base text-white active:scale-95 transition-transform flex items-center justify-center gap-2"
          style={{ background: selected ? '#10B981' : '#FF6542' }}
        >
          {selected ? (
            <>
              <Check size={18} strokeWidth={3} />
              In My Order
            </>
          ) : (
            <>
              <ShoppingCart size={18} />
              Add to My Order
            </>
          )}
        </button>
      </div>
    </div>
  );
}

// ─── Menu Screen ──────────────────────────────────────────────────────────────

function MenuScreen({
  selectedIds,
  onToggleSelect,
  onViewOrder,
}: {
  selectedIds: string[];
  onToggleSelect: (id: string) => void;
  onViewOrder: () => void;
}) {
  const [filter, setFilter] = useState<MenuFilter>('all');
  const [openId, setOpenId] = useState<string | null>(null);
  const [showInfo, setShowInfo] = useState(false);

  const STATUS_ORDER = { top: 0, check: 1, avoid: 2 };
  const filtered = DISHES
    .filter(d =>
      filter === 'all'
        ? true
        : filter === 'top'
        ? d.status === 'top'
        : filter === 'check'
        ? d.status === 'check'
        : d.status === 'avoid'
    )
    .sort((a, b) => STATUS_ORDER[a.status] - STATUS_ORDER[b.status]);

  const openDish = DISHES.find(d => d.id === openId) ?? null;

  const FILTERS: { key: MenuFilter; label: string }[] = [
    { key: 'all', label: 'All' },
    { key: 'top', label: 'Top Picks' },
    { key: 'check', label: 'Check First' },
    { key: 'avoid', label: 'Avoid' },
  ];

  return (
    <div
      className="flex flex-col min-h-screen bg-[#FFFBF7]"
      style={{ paddingBottom: selectedIds.length > 0 ? '8rem' : '5rem' }}
    >
      <div className="px-5 pt-14 pb-2 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-[#1C1917]">Your Menu</h1>
          <p className="text-[#78716C] text-sm">Picked for your taste</p>
        </div>
        <button
          onClick={() => setShowInfo(true)}
          className="w-9 h-9 rounded-full border border-[#EDE8E1] flex items-center justify-center bg-white"
        >
          <Info size={16} style={{ color: '#78716C' }} />
        </button>
      </div>

      <div className="flex gap-2 px-5 py-3 overflow-x-auto scrollbar-hide">
        {FILTERS.map(f => (
          <button
            key={f.key}
            onClick={() => setFilter(f.key)}
            className="px-4 py-2 rounded-full text-sm font-bold whitespace-nowrap transition-all active:scale-95"
            style={
              filter === f.key
                ? { background: '#FF6542', color: '#fff' }
                : { background: '#fff', color: '#78716C', border: '1px solid #EDE8E1' }
            }
          >
            {f.label}
          </button>
        ))}
      </div>

      <div className="px-5 flex flex-col gap-3">
        {filtered.map(dish => (
          <DishCard
            key={dish.id}
            dish={dish}
            selected={selectedIds.includes(dish.id)}
            onSelect={() => onToggleSelect(dish.id)}
            onOpen={() => setOpenId(dish.id)}
          />
        ))}
      </div>

      {selectedIds.length > 0 && (
        <div
          className="fixed left-1/2 -translate-x-1/2 w-full max-w-[430px] px-5"
          style={{ bottom: '4.5rem' }}
        >
          <button
            onClick={onViewOrder}
            className="w-full py-4 rounded-2xl text-white font-black flex items-center justify-between px-5 shadow-xl"
            style={{ background: '#1C1917' }}
          >
            <span className="text-sm font-bold">
              {selectedIds.length} {selectedIds.length === 1 ? 'dish' : 'dishes'} selected
            </span>
            <span className="flex items-center gap-1.5">
              View My Order
              <ChevronRight size={18} strokeWidth={2.5} />
            </span>
          </button>
        </div>
      )}

      {openDish && (
        <DishDetail
          dish={openDish}
          selected={selectedIds.includes(openDish.id)}
          onSelect={() => onToggleSelect(openDish.id)}
          onClose={() => setOpenId(null)}
        />
      )}

      {showInfo && (
        <div
          className="fixed inset-0 z-50 flex items-end"
          style={{ background: 'rgba(0,0,0,0.45)' }}
          onClick={() => setShowInfo(false)}
        >
          <div
            className="w-full max-w-[430px] mx-auto rounded-t-3xl bg-white px-5 pt-5 pb-10"
            onClick={e => e.stopPropagation()}
          >
            <div className="w-10 h-1 rounded-full bg-[#EDE8E1] mx-auto mb-5" />
            <h3 className="font-black text-[#1C1917] mb-3 flex items-center gap-2">
              <Info size={16} style={{ color: '#FF6542' }} />
              About food warnings
            </h3>
            <p className="text-sm text-[#78716C] leading-relaxed">
              YummyNaKha! helps identify possible food conflicts from menu information, but
              restaurant ingredients and preparation can vary. Always confirm serious allergies or
              medical restrictions with restaurant staff.
            </p>
            <button
              onClick={() => setShowInfo(false)}
              className="mt-5 w-full py-3.5 rounded-2xl font-black text-white"
              style={{ background: '#FF6542' }}
            >
              Got it
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── My Order ─────────────────────────────────────────────────────────────────

function MyOrder({
  selectedIds,
  onRemove,
  onAddMore,
  onShowThai,
}: {
  selectedIds: string[];
  onRemove: (id: string) => void;
  onAddMore: () => void;
  onShowThai: () => void;
}) {
  const selected = DISHES.filter(d => selectedIds.includes(d.id));
  const total = selected.reduce((s, d) => s + d.price, 0);

  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7] pb-28">
      <div className="px-5 pt-14 pb-4">
        <h1 className="text-2xl font-black text-[#1C1917]">My Order</h1>
        <p className="text-[#78716C] text-sm">Check your picks</p>
      </div>

      {selected.length === 0 ? (
        <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
          <div
            className="w-16 h-16 rounded-2xl flex items-center justify-center mb-4"
            style={{ background: '#F5F0E8' }}
          >
            <ShoppingCart size={28} style={{ color: '#A8A29E' }} />
          </div>
          <p className="text-[#78716C] font-bold mb-5">No dishes selected yet.</p>
          <button
            onClick={onAddMore}
            className="px-8 py-3.5 rounded-2xl font-black text-white"
            style={{ background: '#FF6542' }}
          >
            Browse Menu
          </button>
        </div>
      ) : (
        <div className="px-5 flex flex-col gap-3">
          {selected.map(dish => {
            const DishIcon = dish.Icon;
            return (
              <div
                key={dish.id}
                className="flex items-center gap-3 bg-white rounded-2xl p-4 border border-[#EDE8E1] shadow-sm"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center shrink-0"
                  style={{ background: dish.bg }}
                >
                  <DishIcon size={22} style={{ color: dish.iconColor }} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-black text-[#1C1917] text-sm leading-tight">{dish.nameEn}</p>
                  <p className="text-sm text-[#A8A29E] font-thai">{dish.nameThai}</p>
                  <p className="text-sm font-black" style={{ color: '#FF6542' }}>฿{dish.price}</p>
                </div>
                <button
                  onClick={() => onRemove(dish.id)}
                  className="text-[#C4BBB4] hover:text-[#EF4444] transition-colors p-1 flex items-center"
                >
                  <Trash2 size={15} />
                </button>
              </div>
            );
          })}

          <div className="bg-white rounded-2xl border border-[#EDE8E1] p-4 flex justify-between items-center">
            <span className="text-sm font-bold text-[#78716C]">
              {selected.length} {selected.length === 1 ? 'dish' : 'dishes'}
            </span>
            <span className="text-lg font-black text-[#1C1917]">Total: ฿{total}</span>
          </div>

          <button
            onClick={onAddMore}
            className="py-3.5 rounded-2xl font-bold border border-[#EDE8E1] text-[#78716C] hover:border-[#FF6542] hover:text-[#FF6542] transition-colors flex items-center justify-center gap-2"
          >
            <ArrowLeft size={16} />
            Add More
          </button>
          <button
            onClick={onShowThai}
            className="py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2"
            style={{ background: '#FF6542' }}
          >
            <Languages size={18} />
            Show in Thai
          </button>
        </div>
      )}
    </div>
  );
}

// ─── Show In Thai ─────────────────────────────────────────────────────────────

function ShowInThai({
  selectedIds,
  onBack,
}: {
  selectedIds: string[];
  onBack: () => void;
}) {
  const selected = DISHES.filter(d => selectedIds.includes(d.id));
  const total = selected.reduce((s, d) => s + d.price, 0);

  return (
    <div className="flex flex-col min-h-screen bg-white">
      <div className="px-5 pt-14 pb-6 border-b border-[#EDE8E1] text-center">
        <p className="text-xs font-bold text-[#A8A29E] uppercase tracking-widest mb-2">
          Show this to your server
        </p>
        <h1 className="text-2xl font-bold text-[#1C1917] font-thai">
          รายการที่ต้องการสั่ง
        </h1>
      </div>

      <div className="flex-1 px-5 py-6 flex flex-col gap-4">
        {selected.map(dish => (
          <div key={dish.id} className="p-5 rounded-2xl border-2 border-[#EDE8E1]">
            <p
              className="font-bold text-[#1C1917] font-thai"
              style={{ fontSize: '2rem', lineHeight: 1.3 }}
            >
              {dish.nameThai}
            </p>
            <p
              className="font-black font-thai mt-2"
              style={{ fontSize: '1.5rem', color: '#FF6542' }}
            >
              {dish.price} บาท
            </p>
          </div>
        ))}

        <div className="p-5 rounded-2xl text-right" style={{ background: '#FFF0E8' }}>
          <p
            className="font-black font-thai"
            style={{ fontSize: '1.75rem', color: '#FF6542' }}
          >
            รวม {total} บาท
          </p>
        </div>
      </div>

      <div className="px-5 pb-12 text-center">
        <button
          onClick={onBack}
          className="flex items-center justify-center gap-1.5 text-sm font-bold text-[#A8A29E] underline underline-offset-2 mx-auto"
        >
          <ArrowLeft size={14} />
          Back to English
        </button>
      </div>
    </div>
  );
}

// ─── Google Icon ─────────────────────────────────────────────────────────────

function GoogleIcon({ size = 18 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none">
      <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4" />
      <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853" />
      <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05" />
      <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335" />
    </svg>
  );
}

// ─── Shared Auth Shell ────────────────────────────────────────────────────────

function AuthShell({ children, title, subtitle }: { children: React.ReactNode; title: string; subtitle: string }) {
  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7]">
      <div className="flex flex-col items-center pt-16 pb-8 px-6">
        <div className="w-14 h-14 rounded-2xl flex items-center justify-center mb-5 shadow-sm" style={{ background: '#FF6542' }}>
          <UtensilsCrossed size={26} color="#fff" strokeWidth={2} />
        </div>
        <h1 className="text-2xl font-black text-[#1C1917]">{title}</h1>
        <p className="text-sm text-[#78716C] mt-1 text-center">{subtitle}</p>
      </div>
      <div className="flex-1 px-6 pb-10">{children}</div>
    </div>
  );
}

function PasswordInput({
  value,
  onChange,
  placeholder,
  label,
}: {
  value: string;
  onChange: (v: string) => void;
  placeholder: string;
  label: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <div>
      <label className="text-xs font-bold text-[#78716C] uppercase tracking-wider mb-1.5 block">{label}</label>
      <div className="relative">
        <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
          <Lock size={16} style={{ color: '#A8A29E' }} />
        </div>
        <input
          type={show ? 'text' : 'password'}
          value={value}
          onChange={e => onChange(e.target.value)}
          placeholder={placeholder}
          className="w-full rounded-xl pl-10 pr-11 py-3.5 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
        />
        <button
          type="button"
          onClick={() => setShow(s => !s)}
          className="absolute right-3.5 top-1/2 -translate-y-1/2"
        >
          {show
            ? <EyeOff size={16} style={{ color: '#A8A29E' }} />
            : <Eye size={16} style={{ color: '#A8A29E' }} />}
        </button>
      </div>
    </div>
  );
}

// ─── Sign In ──────────────────────────────────────────────────────────────────

function SignIn({
  onSignIn,
  onGoogleSignIn,
  onGoSignUp,
  onForgot,
}: {
  onSignIn: (email: string, name: string) => void;
  onGoogleSignIn: () => void;
  onGoSignUp: () => void;
  onForgot: () => void;
}) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim() || !password.trim()) {
      setError('Please enter your email and password.');
      return;
    }
    const name = email.split('@')[0];
    onSignIn(email.trim(), name);
  }

  return (
    <AuthShell title="Welcome back" subtitle="Sign in to your YummyNaKha! account">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-xs font-bold text-[#78716C] uppercase tracking-wider mb-1.5 block">Email</label>
          <div className="relative">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
              <Mail size={16} style={{ color: '#A8A29E' }} />
            </div>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-xl pl-10 pr-4 py-3.5 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
            />
          </div>
        </div>

        <PasswordInput value={password} onChange={setPassword} placeholder="Your password" label="Password" />

        <div className="text-right -mt-1">
          <button type="button" onClick={onForgot} className="text-xs font-bold" style={{ color: '#FF6542' }}>
            Forgot password?
          </button>
        </div>

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold" style={{ background: '#FEF2F2', color: '#991B1B' }}>
            <AlertTriangle size={13} />
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2"
          style={{ background: '#FF6542' }}
        >
          Sign In
          <ChevronRight size={18} strokeWidth={2.5} />
        </button>

        <div className="flex items-center gap-3 my-1">
          <div className="flex-1 h-px" style={{ background: '#EDE8E1' }} />
          <span className="text-xs font-bold text-[#A8A29E]">or</span>
          <div className="flex-1 h-px" style={{ background: '#EDE8E1' }} />
        </div>

        <button
          type="button"
          onClick={onGoogleSignIn}
          className="w-full py-3.5 rounded-2xl font-bold text-sm border border-[#EDE8E1] bg-white flex items-center justify-center gap-2.5 hover:border-[#C4BBB4] active:scale-95 transition-all"
          style={{ color: '#1C1917' }}
        >
          <GoogleIcon size={18} />
          Continue with Google
        </button>

        <p className="text-center text-sm text-[#78716C] mt-2">
          Don't have an account?{' '}
          <button type="button" onClick={onGoSignUp} className="font-black" style={{ color: '#FF6542' }}>
            Sign up
          </button>
        </p>
      </form>
    </AuthShell>
  );
}

// ─── Sign Up ──────────────────────────────────────────────────────────────────

function SignUp({
  onSignUp,
  onGoogleSignIn,
  onGoSignIn,
}: {
  onSignUp: (email: string, name: string) => void;
  onGoogleSignIn: () => void;
  onGoSignIn: () => void;
}) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!name.trim() || !email.trim() || !password.trim()) {
      setError('Please fill in all fields.');
      return;
    }
    if (password.length < 6) {
      setError('Password must be at least 6 characters.');
      return;
    }
    onSignUp(email.trim(), name.trim());
  }

  return (
    <AuthShell title="Create account" subtitle="Join YummyNaKha! — it's free">
      <form onSubmit={handleSubmit} className="flex flex-col gap-4">
        <div>
          <label className="text-xs font-bold text-[#78716C] uppercase tracking-wider mb-1.5 block">Your name</label>
          <div className="relative">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
              <CircleUser size={16} style={{ color: '#A8A29E' }} />
            </div>
            <input
              type="text"
              value={name}
              onChange={e => setName(e.target.value)}
              placeholder="How should we call you?"
              className="w-full rounded-xl pl-10 pr-4 py-3.5 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
            />
          </div>
        </div>

        <div>
          <label className="text-xs font-bold text-[#78716C] uppercase tracking-wider mb-1.5 block">Email</label>
          <div className="relative">
            <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
              <Mail size={16} style={{ color: '#A8A29E' }} />
            </div>
            <input
              type="email"
              value={email}
              onChange={e => setEmail(e.target.value)}
              placeholder="you@example.com"
              className="w-full rounded-xl pl-10 pr-4 py-3.5 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
            />
          </div>
        </div>

        <PasswordInput value={password} onChange={setPassword} placeholder="Create a password (min. 6 chars)" label="Password" />

        {error && (
          <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold" style={{ background: '#FEF2F2', color: '#991B1B' }}>
            <AlertTriangle size={13} />
            {error}
          </div>
        )}

        <button
          type="submit"
          className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2"
          style={{ background: '#FF6542' }}
        >
          Create Account
          <ChevronRight size={18} strokeWidth={2.5} />
        </button>

        <div className="flex items-center gap-3 my-1">
          <div className="flex-1 h-px" style={{ background: '#EDE8E1' }} />
          <span className="text-xs font-bold text-[#A8A29E]">or</span>
          <div className="flex-1 h-px" style={{ background: '#EDE8E1' }} />
        </div>

        <button
          type="button"
          onClick={onGoogleSignIn}
          className="w-full py-3.5 rounded-2xl font-bold text-sm border border-[#EDE8E1] bg-white flex items-center justify-center gap-2.5 hover:border-[#C4BBB4] active:scale-95 transition-all"
          style={{ color: '#1C1917' }}
        >
          <GoogleIcon size={18} />
          Continue with Google
        </button>

        <p className="text-center text-sm text-[#78716C] mt-2">
          Already have an account?{' '}
          <button type="button" onClick={onGoSignIn} className="font-black" style={{ color: '#FF6542' }}>
            Sign in
          </button>
        </p>
      </form>
    </AuthShell>
  );
}

// ─── Forgot Password ──────────────────────────────────────────────────────────

function ForgotPassword({ onBack }: { onBack: () => void }) {
  const [email, setEmail] = useState('');
  const [sent, setSent] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!email.trim()) return;
    setSent(true);
  }

  return (
    <AuthShell
      title="Reset password"
      subtitle={sent ? 'Check your inbox' : "We'll send you a reset link"}
    >
      {sent ? (
        <div className="flex flex-col items-center text-center gap-5">
          <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: '#ECFDF5' }}>
            <Check size={28} strokeWidth={3} style={{ color: '#10B981' }} />
          </div>
          <div>
            <p className="font-black text-[#1C1917] mb-1">Link sent!</p>
            <p className="text-sm text-[#78716C] leading-relaxed">
              We sent a password reset link to{' '}
              <span className="font-bold text-[#1C1917]">{email}</span>. Check your inbox and follow the instructions.
            </p>
          </div>
          <button
            onClick={onBack}
            className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md"
            style={{ background: '#FF6542' }}
          >
            Back to Sign In
          </button>
        </div>
      ) : (
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <p className="text-sm text-[#78716C] leading-relaxed -mt-2">
            Enter your email address and we'll send you a link to reset your password.
          </p>

          <div>
            <label className="text-xs font-bold text-[#78716C] uppercase tracking-wider mb-1.5 block">Email</label>
            <div className="relative">
              <div className="absolute left-3.5 top-1/2 -translate-y-1/2">
                <Mail size={16} style={{ color: '#A8A29E' }} />
              </div>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="w-full rounded-xl pl-10 pr-4 py-3.5 text-sm border border-[#EDE8E1] bg-white focus:outline-none focus:border-[#FF6542] transition-colors"
              />
            </div>
          </div>

          <button
            type="submit"
            className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2"
            style={{ background: '#FF6542' }}
          >
            <Mail size={18} />
            Send Reset Link
          </button>

          <button type="button" onClick={onBack} className="flex items-center justify-center gap-1.5 text-sm font-bold text-[#A8A29E] mx-auto">
            <ChevronLeft size={16} />
            Back to Sign In
          </button>
        </form>
      )}
    </AuthShell>
  );
}

// ─── Profile ──────────────────────────────────────────────────────────────────

function Profile({
  user,
  onChangePassword,
  onSignOut,
  onBack,
}: {
  user: AppUser;
  onUpdateName: (name: string) => void;
  onChangePassword: () => void;
  onSignOut: () => void;
  onBack: () => void;
}) {
  const [editing, setEditing] = useState(false);
  const [nameInput, setNameInput] = useState(user.name);
  const [nameError, setNameError] = useState('');

  function saveUsername() {
    const v = nameInput.trim();
    if (!v) { setNameError('Username cannot be empty.'); return; }
    onUpdateName(v);
    setEditing(false);
    setNameError('');
  }

  function cancelEdit() {
    setNameInput(user.name);
    setNameError('');
    setEditing(false);
  }

  const initials = (user?.name ?? 'YN')
    .split(' ')
    .map((w: string) => w[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);

  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7]">
      {/* Header */}
      <div className="flex items-center gap-3 px-5 pt-14 pb-5">
        <button onClick={onBack} className="flex items-center justify-center w-9 h-9 rounded-full border border-[#EDE8E1] bg-white">
          <ChevronLeft size={18} style={{ color: '#78716C' }} />
        </button>
        <h1 className="text-xl font-black text-[#1C1917]">My Profile</h1>
      </div>

      {/* Avatar + name */}
      <div className="flex flex-col items-center pb-8 px-6">
        <div
          className="w-20 h-20 rounded-full flex items-center justify-center text-2xl font-black text-white mb-3 shadow-md"
          style={{ background: '#FF6542' }}
        >
          {initials}
        </div>
        <h2 className="text-xl font-black text-[#1C1917]">{user.name}</h2>
        <p className="text-sm text-[#78716C] mt-0.5">{user.email}</p>
      </div>

      {/* Info card */}
      <div className="mx-5 mb-4 rounded-2xl bg-white border border-[#EDE8E1] overflow-hidden shadow-sm">
        {/* Username row — editable */}
        <div className="px-4 py-3.5 border-b border-[#EDE8E1]">
          <div className="flex items-center justify-between mb-0.5">
            <p className="text-xs font-bold text-[#A8A29E] uppercase tracking-wider">Username</p>
            {!editing && (
              <button
                onClick={() => { setNameInput(user.name); setEditing(true); }}
                className="text-xs font-bold"
                style={{ color: '#FF6542' }}
              >
                Edit
              </button>
            )}
          </div>

          {editing ? (
            <div className="mt-1.5 flex flex-col gap-2">
              <input
                autoFocus
                type="text"
                value={nameInput}
                onChange={e => { setNameInput(e.target.value); setNameError(''); }}
                onKeyDown={e => { if (e.key === 'Enter') saveUsername(); if (e.key === 'Escape') cancelEdit(); }}
                className="w-full rounded-xl px-3.5 py-2.5 text-sm font-bold border border-[#EDE8E1] focus:outline-none focus:border-[#FF6542] transition-colors bg-[#FFFBF7]"
              />
              {nameError && (
                <p className="text-xs font-semibold flex items-center gap-1" style={{ color: '#991B1B' }}>
                  <AlertTriangle size={11} />
                  {nameError}
                </p>
              )}
              <div className="flex gap-2">
                <button
                  onClick={saveUsername}
                  className="flex-1 py-2 rounded-xl text-xs font-black text-white flex items-center justify-center gap-1"
                  style={{ background: '#FF6542' }}
                >
                  <Check size={13} strokeWidth={3} />
                  Save
                </button>
                <button
                  onClick={cancelEdit}
                  className="flex-1 py-2 rounded-xl text-xs font-bold border border-[#EDE8E1] text-[#78716C]"
                >
                  Cancel
                </button>
              </div>
            </div>
          ) : (
            <p className="text-sm font-bold text-[#1C1917]">{user.name}</p>
          )}
        </div>

        {/* Email row — read only */}
        <div className="px-4 py-3.5">
          <p className="text-xs font-bold text-[#A8A29E] uppercase tracking-wider mb-0.5">Email</p>
          <p className="text-sm font-bold text-[#1C1917]">{user.email}</p>
        </div>
      </div>

      {/* Actions */}
      <div className="mx-5 rounded-2xl bg-white border border-[#EDE8E1] overflow-hidden shadow-sm">
        <button
          onClick={onChangePassword}
          className="w-full flex items-center justify-between px-4 py-4 hover:bg-[#FFFBF7] transition-colors border-b border-[#EDE8E1]"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#FFF0E8' }}>
              <KeyRound size={16} style={{ color: '#FF6542' }} />
            </div>
            <span className="text-sm font-bold text-[#1C1917]">Change Password</span>
          </div>
          <ChevronRight size={16} style={{ color: '#A8A29E' }} />
        </button>

        <button
          onClick={onSignOut}
          className="w-full flex items-center justify-between px-4 py-4 hover:bg-[#FFFBF7] transition-colors"
        >
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-xl flex items-center justify-center" style={{ background: '#FEF2F2' }}>
              <LogOut size={16} style={{ color: '#EF4444' }} />
            </div>
            <span className="text-sm font-bold" style={{ color: '#EF4444' }}>Sign Out</span>
          </div>
          <ChevronRight size={16} style={{ color: '#A8A29E' }} />
        </button>
      </div>
    </div>
  );
}

// ─── Change Password ──────────────────────────────────────────────────────────

function ChangePassword({ onBack }: { onBack: () => void }) {
  const [current, setCurrent] = useState('');
  const [next, setNext] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!current || !next || !confirm) {
      setError('Please fill in all fields.');
      return;
    }
    if (next.length < 6) {
      setError('New password must be at least 6 characters.');
      return;
    }
    if (next !== confirm) {
      setError("New passwords don't match.");
      return;
    }
    setError('');
    setSuccess(true);
  }

  return (
    <div className="flex flex-col min-h-screen bg-[#FFFBF7]">
      <div className="flex items-center gap-3 px-5 pt-14 pb-6">
        <button onClick={onBack} className="flex items-center justify-center w-9 h-9 rounded-full border border-[#EDE8E1] bg-white">
          <ChevronLeft size={18} style={{ color: '#78716C' }} />
        </button>
        <h1 className="text-xl font-black text-[#1C1917]">Change Password</h1>
      </div>

      <div className="flex-1 px-5">
        {success ? (
          <div className="flex flex-col items-center text-center gap-5 pt-8">
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ background: '#ECFDF5' }}>
              <Check size={28} strokeWidth={3} style={{ color: '#10B981' }} />
            </div>
            <div>
              <p className="font-black text-[#1C1917] mb-1">Password updated!</p>
              <p className="text-sm text-[#78716C]">Your password has been changed successfully.</p>
            </div>
            <button
              onClick={onBack}
              className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md"
              style={{ background: '#FF6542' }}
            >
              Back to Profile
            </button>
          </div>
        ) : (
          <form onSubmit={handleSubmit} className="flex flex-col gap-4">
            <PasswordInput value={current} onChange={setCurrent} placeholder="Enter current password" label="Current Password" />
            <PasswordInput value={next} onChange={setNext} placeholder="At least 6 characters" label="New Password" />
            <PasswordInput value={confirm} onChange={setConfirm} placeholder="Repeat new password" label="Confirm New Password" />

            {error && (
              <div className="flex items-center gap-2 px-3 py-2.5 rounded-xl text-xs font-semibold" style={{ background: '#FEF2F2', color: '#991B1B' }}>
                <AlertTriangle size={13} />
                {error}
              </div>
            )}

            <button
              type="submit"
              className="w-full py-4 rounded-2xl text-white font-black text-base shadow-md active:scale-95 transition-transform flex items-center justify-center gap-2 mt-2"
              style={{ background: '#FF6542' }}
            >
              <KeyRound size={18} />
              Update Password
            </button>
          </form>
        )}
      </div>
    </div>
  );
}

// ─── Bottom Nav ───────────────────────────────────────────────────────────────

function BottomNav({
  screen,
  orderCount,
  onNavigate,
}: {
  screen: Screen;
  orderCount: number;
  onNavigate: (s: Screen) => void;
}) {
  const activeTab = ['home', 'menu', 'analyzing'].includes(screen)
    ? 'home'
    : ['order', 'thai'].includes(screen)
    ? 'order'
    : 'taste';

  const NAV_ITEMS: { key: Screen; Icon: React.FC<{ size: number }>; label: string }[] = [
    { key: 'home', Icon: HomeIcon, label: 'Home' },
    { key: 'order', Icon: ShoppingBag, label: 'My Order' },
    { key: 'taste', Icon: Heart, label: 'My Taste' },
  ];

  return (
    <div
      className="fixed bottom-0 left-1/2 -translate-x-1/2 w-full max-w-[430px] bg-white border-t border-[#EDE8E1] flex"
      style={{ paddingBottom: 'env(safe-area-inset-bottom, 6px)' }}
    >
      {NAV_ITEMS.map(({ key, Icon, label }) => {
        const active = activeTab === key;
        return (
          <button
            key={key}
            onClick={() => onNavigate(key)}
            className="flex-1 flex flex-col items-center py-3 gap-0.5 relative"
          >
            <Icon size={22} style={{ color: active ? '#FF6542' : '#A8A29E' }} />
            <span
              className="text-xs font-black"
              style={{ color: active ? '#FF6542' : '#A8A29E' }}
            >
              {label}
            </span>
            {key === 'order' && orderCount > 0 && (
              <span
                className="absolute top-2 right-[calc(50%-20px)] w-[18px] h-[18px] rounded-full text-white flex items-center justify-center font-black"
                style={{ background: '#FF6542', fontSize: '9px' }}
              >
                {orderCount}
              </span>
            )}
          </button>
        );
      })}
    </div>
  );
}

// ─── App ──────────────────────────────────────────────────────────────────────

export default function App() {
  const [screen, setScreen] = useState<Screen>('welcome');
  const [hasOnboarded, setHasOnboarded] = useState(false);
  const [profile, setProfile] = useState<TasteProfile>(DEFAULT_PROFILE);
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [user, setUser] = useState<AppUser | null>(null);

  function toggle(id: string) {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]
    );
  }

  function navigate(s: Screen) {
    if (s === 'home') setScreen('home');
    else if (s === 'order') setScreen('order');
    else if (s === 'taste') setScreen('taste');
  }

  function handleSignIn(email: string, name: string) {
    setUser({ email, name });
    setScreen(hasOnboarded ? 'home' : 'taste');
  }

  function handleSignUp(email: string, name: string) {
    setUser({ email, name });
    setScreen('taste');
  }

  function handleGoogleSignIn() {
    setUser({ name: 'Google User', email: 'user@gmail.com' });
    setScreen(hasOnboarded ? 'home' : 'taste');
  }

  function handleSignOut() {
    setUser(null);
    setHasOnboarded(false);
    setSelectedIds([]);
    setScreen('welcome');
  }

  const PROTECTED: Screen[] = ['home', 'taste', 'analyzing', 'menu', 'order', 'thai', 'profile', 'changepassword'];
  const NO_NAV_SCREENS: Screen[] = ['welcome', 'signin', 'signup', 'forgot', 'analyzing', 'thai', 'profile', 'changepassword'];
  const showNav = hasOnboarded && user !== null && !NO_NAV_SCREENS.includes(screen);

  useEffect(() => {
    if (!user && PROTECTED.includes(screen)) {
      setScreen('signin');
    }
  }, [user, screen]);

  return (
    <div className="flex items-start justify-center min-h-screen" style={{ background: '#EDE8E1' }}>
      <div
        className="relative w-full max-w-[430px] min-h-screen overflow-hidden"
        style={{ background: '#FFFBF7' }}
      >
        {screen === 'welcome' && (
          <Welcome onStart={() => setScreen('signin')} />
        )}
        {screen === 'signin' && (
          <SignIn
            onSignIn={handleSignIn}
            onGoogleSignIn={handleGoogleSignIn}
            onGoSignUp={() => setScreen('signup')}
            onForgot={() => setScreen('forgot')}
          />
        )}
        {screen === 'signup' && (
          <SignUp
            onSignUp={handleSignUp}
            onGoogleSignIn={handleGoogleSignIn}
            onGoSignIn={() => setScreen('signin')}
          />
        )}
        {screen === 'forgot' && (
          <ForgotPassword onBack={() => setScreen('signin')} />
        )}
        {screen === 'taste' && (
          <MyTaste
            profile={profile}
            setProfile={setProfile}
            onSave={() => { setHasOnboarded(true); setScreen('home'); }}
            showNav={hasOnboarded}
          />
        )}
        {screen === 'home' && user && (
          <Home
            profile={profile}
            user={user}
            onFindFood={() => setScreen('analyzing')}
            onEditTaste={() => setScreen('taste')}
            onProfile={() => setScreen('profile')}
          />
        )}
        {screen === 'analyzing' && (
          <Analyzing onDone={() => setScreen('menu')} />
        )}
        {screen === 'menu' && (
          <MenuScreen
            selectedIds={selectedIds}
            onToggleSelect={toggle}
            onViewOrder={() => setScreen('order')}
          />
        )}
        {screen === 'order' && (
          <MyOrder
            selectedIds={selectedIds}
            onRemove={toggle}
            onAddMore={() => setScreen('menu')}
            onShowThai={() => setScreen('thai')}
          />
        )}
        {screen === 'thai' && (
          <ShowInThai selectedIds={selectedIds} onBack={() => setScreen('order')} />
        )}
        {screen === 'profile' && user && (
          <Profile
            user={user}
            onUpdateName={(name) => setUser({ ...user, name })}
            onChangePassword={() => setScreen('changepassword')}
            onSignOut={handleSignOut}
            onBack={() => setScreen('home')}
          />
        )}
        {screen === 'changepassword' && (
          <ChangePassword onBack={() => setScreen('profile')} />
        )}
        {showNav && (
          <BottomNav
            screen={screen}
            orderCount={selectedIds.length}
            onNavigate={navigate}
          />
        )}
      </div>
    </div>
  );
}
